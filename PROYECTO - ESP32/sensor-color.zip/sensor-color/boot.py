# This file is executed on every boot (including wake-boot from deepsleep)
import webpage

webpage.web_page()